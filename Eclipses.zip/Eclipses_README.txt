Eclipse data downloaded by event in KMZ format here: http://xjubier.free.fr/en/site_pages/SolarEclipsesGoogleEarth.html

Process:

Used the Esri KML to Layer tool on each KMZ to export to a layer file.
Exported the polygon portion of said layer file to a shapefile
Used Esri's Merge(Data Management) tool to merge all the individual polygon shapefiles into one.